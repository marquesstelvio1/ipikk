import { Menu, X, ChevronDown, ChevronRight } from "lucide-react";
import { Button } from "./ui/button";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Logo } from "./Logo";
import { LanguageSelector } from "./LanguageSelector";
import { ThemeToggle } from "./ThemeToggle";
import { useLanguage } from "../contexts/LanguageContext";

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isCoursesOpen, setIsCoursesOpen] = useState(false);
  const [hoveredArea, setHoveredArea] = useState<string | null>(null);
  const [isMobileCoursesOpen, setIsMobileCoursesOpen] = useState(false);
  const [mobileOpenAreas, setMobileOpenAreas] = useState<string[]>([]);
  
  const { t } = useLanguage();

  const menuItems = [
    { name: t("nav.home"), href: "#home" },
    { name: t("nav.about"), href: "#about" },
  ];

  const courseAreas = [
    {
      name: "Informática",
      courses: [
        { name: "Técnico de Informática", href: "#tecnico-informatica" },
        { name: "Gestão de Sistemas Informáticos", href: "#gestao-sistemas" }
      ]
    },
    {
      name: "Contabilidade",
      courses: [
        { name: "Contabilidade", href: "#contabilidade" },
        { name: "Auditoria", href: "#auditoria" }
      ]
    },
    {
      name: "Eletricidade",
      courses: [
        { name: "Instalações Elétricas", href: "#instalacoes-eletricas" },
        { name: "Eletrónica Industrial", href: "#eletronica-industrial" }
      ]
    },
    {
      name: "Mecânica",
      courses: [
        { name: "Mecânica Automóvel", href: "#mecanica-automovel" },
        { name: "Manutenção Industrial", href: "#manutencao-industrial" }
      ]
    },
    {
      name: "Construção Civil",
      courses: [
        { name: "Construção Civil", href: "#construcao-civil" },
        { name: "Topografia", href: "#topografia" }
      ]
    },
    {
      name: "Gestão e Administração",
      courses: [
        { name: "Gestão de Empresas", href: "#gestao-empresas" },
        { name: "Secretariado", href: "#secretariado" }
      ]
    }
  ];

  const otherMenuItems = [
    { name: t("nav.admissions"), href: "#admissions" },
    { name: t("nav.news"), href: "#news" },
    { name: t("nav.contact"), href: "#contact" }
  ];

  const toggleMobileArea = (areaName: string) => {
    setMobileOpenAreas(prev => 
      prev.includes(areaName) 
        ? prev.filter(name => name !== areaName)
        : [...prev, areaName]
    );
  };

  return (
    <motion.nav 
      className="bg-white dark:bg-gray-800 border-b dark:border-gray-700 sticky top-0 z-50 transition-colors duration-300"
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.5, delay: 3 }}
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16 items-center">
          {/* Logo */}
          <motion.div 
            className="flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            transition={{ duration: 0.2 }}
          >
            <Logo size="sm" />
            <span className="text-blue-600">IPIKK</span>
          </motion.div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-8">
            {menuItems.map((item, index) => (
              <motion.a
                key={index}
                href={item.href}
                className="text-gray-700 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400 transition-colors"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 3 + index * 0.1 }}
                whileHover={{ y: -2 }}
              >
                {item.name}
              </motion.a>
            ))}
            
            {/* Dropdown de Cursos - Desktop com Hover e Sub-submenu */}
            <div 
              className="relative group"
              onMouseEnter={() => setIsCoursesOpen(true)}
              onMouseLeave={() => {
                setIsCoursesOpen(false);
                setHoveredArea(null);
              }}
            >
              <motion.a
                href="#cursos"
                className="text-gray-700 hover:text-blue-600 transition-colors flex items-center gap-1 cursor-pointer"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 3.2 }}
                whileHover={{ y: -2 }}
              >
                Cursos <ChevronDown className={`h-4 w-4 transition-transform duration-300 ${isCoursesOpen ? 'rotate-180' : ''}`} />
              </motion.a>
              
              <AnimatePresence>
                {isCoursesOpen && (
                  <motion.div
                    className="absolute left-0 mt-2 w-64 bg-white border border-gray-200 rounded-lg shadow-lg overflow-visible"
                    initial={{ opacity: 0, y: -10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -10 }}
                    transition={{ duration: 0.2 }}
                  >
                    {courseAreas.map((area, index) => (
                      <div
                        key={index}
                        className="relative"
                        onMouseEnter={() => setHoveredArea(area.name)}
                        onMouseLeave={() => setHoveredArea(null)}
                      >
                        <motion.div
                          className="flex items-center justify-between px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors cursor-pointer"
                          initial={{ opacity: 0, x: -10 }}
                          animate={{ opacity: 1, x: 0 }}
                          transition={{ duration: 0.2, delay: index * 0.03 }}
                        >
                          <span>{area.name}</span>
                          <ChevronRight className="h-4 w-4" />
                        </motion.div>

                        {/* Sub-submenu */}
                        <AnimatePresence>
                          {hoveredArea === area.name && (
                            <motion.div
                              className="absolute left-full top-0 ml-1 w-64 bg-white border border-gray-200 rounded-lg shadow-lg overflow-hidden"
                              initial={{ opacity: 0, x: -10 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: -10 }}
                              transition={{ duration: 0.2 }}
                            >
                              {area.courses.map((course, courseIndex) => (
                                <motion.a
                                  key={courseIndex}
                                  href={course.href}
                                  className="block px-4 py-3 text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                                  initial={{ opacity: 0, x: -10 }}
                                  animate={{ opacity: 1, x: 0 }}
                                  transition={{ duration: 0.2, delay: courseIndex * 0.03 }}
                                >
                                  {course.name}
                                </motion.a>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {otherMenuItems.map((item, index) => (
              <motion.a
                key={index}
                href={item.href}
                className="text-gray-700 hover:text-blue-600 transition-colors"
                initial={{ opacity: 0, y: -20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: 3.3 + index * 0.1 }}
                whileHover={{ y: -2 }}
              >
                {item.name}
              </motion.a>
            ))}
          </div>

          {/* CTA Button + Language + Theme */}
          <motion.div 
            className="hidden md:flex items-center gap-3"
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3, delay: 3.6 }}
          >
            <ThemeToggle />
            <LanguageSelector />
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button>{t("nav.signup")}</Button>
            </motion.div>
          </motion.div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              className="md:hidden py-4 space-y-3"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              {menuItems.map((item, index) => (
                <motion.a
                  key={index}
                  href={item.href}
                  className="block text-gray-700 hover:text-blue-600 transition-colors py-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2, delay: index * 0.05 }}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </motion.a>
              ))}
              
              {/* Dropdown de Cursos - Mobile (com clique e sub-submenus) */}
              <div>
                <button
                  className="flex items-center gap-1 text-gray-700 hover:text-blue-600 transition-colors py-2 w-full"
                  onClick={() => setIsMobileCoursesOpen(!isMobileCoursesOpen)}
                >
                  Cursos <ChevronDown className={`h-4 w-4 transition-transform duration-300 ${isMobileCoursesOpen ? 'rotate-180' : ''}`} />
                </button>
                <AnimatePresence>
                  {isMobileCoursesOpen && (
                    <motion.div
                      className="pl-4 space-y-2 mt-2"
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      transition={{ duration: 0.2 }}
                    >
                      {courseAreas.map((area, index) => (
                        <div key={index}>
                          <button
                            className="flex items-center justify-between w-full text-gray-600 hover:text-blue-600 transition-colors py-2"
                            onClick={() => toggleMobileArea(area.name)}
                          >
                            <span>{area.name}</span>
                            <ChevronDown className={`h-4 w-4 transition-transform duration-300 ${mobileOpenAreas.includes(area.name) ? 'rotate-180' : ''}`} />
                          </button>
                          <AnimatePresence>
                            {mobileOpenAreas.includes(area.name) && (
                              <motion.div
                                className="pl-4 space-y-1 mt-1"
                                initial={{ opacity: 0, height: 0 }}
                                animate={{ opacity: 1, height: "auto" }}
                                exit={{ opacity: 0, height: 0 }}
                                transition={{ duration: 0.2 }}
                              >
                                {area.courses.map((course, courseIndex) => (
                                  <motion.a
                                    key={courseIndex}
                                    href={course.href}
                                    className="block text-gray-500 hover:text-blue-600 transition-colors py-2"
                                    initial={{ opacity: 0, x: -10 }}
                                    animate={{ opacity: 1, x: 0 }}
                                    transition={{ duration: 0.2, delay: courseIndex * 0.03 }}
                                    onClick={() => {
                                      setIsMenuOpen(false);
                                      setIsMobileCoursesOpen(false);
                                      setMobileOpenAreas([]);
                                    }}
                                  >
                                    {course.name}
                                  </motion.a>
                                ))}
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      ))}
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              {otherMenuItems.map((item, index) => (
                <motion.a
                  key={index}
                  href={item.href}
                  className="block text-gray-700 hover:text-blue-600 transition-colors py-2"
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  transition={{ duration: 0.2, delay: (index + 2) * 0.05 }}
                  onClick={() => setIsMenuOpen(false)}
                >
                  {item.name}
                </motion.a>
              ))}
              
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2, delay: 0.4 }}
                className="pt-2"
              >
                <Button className="w-full">Inscreva-se</Button>
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.nav>
  );
}