import { motion } from "motion/react";
import { GraduationCap } from "lucide-react";
import { Logo } from "./Logo";

interface SplashScreenProps {
  onComplete: () => void;
}

export function SplashScreen({ onComplete }: SplashScreenProps) {
  // Cores representando os diferentes cursos
  const courseColors = [
    ["#2563eb", "#1e40af"], // Azul - Academic Excellence
    ["#16a34a", "#15803d"], // Verde - STEM Programs
    ["#9333ea", "#7e22ce"], // Roxo - Arts & Culture
    ["#ea580c", "#c2410c"], // Laranja - Athletics & Sports
    ["#dc2626", "#b91c1c"], // Vermelho - Additional Programs
    ["#eab308", "#ca8a04"], // Amarelo - Innovation
  ];

  return (
    <motion.div
      className="fixed inset-0 z-[100] flex items-center justify-center"
      initial={{ opacity: 1 }}
      animate={{ opacity: 0 }}
      transition={{ duration: 0.5, delay: 2.5 }}
      onAnimationComplete={onComplete}
      style={{
        background: `linear-gradient(to bottom right, ${courseColors[0][0]}, ${courseColors[0][1]})`
      }}
    >
      {/* Animated Background */}
      <motion.div
        className="absolute inset-0"
        animate={{
          background: courseColors.map(colors => 
            `linear-gradient(to bottom right, ${colors[0]}, ${colors[1]})`
          )
        }}
        transition={{
          duration: 1.5,
          repeat: 1,
          repeatType: "loop",
          ease: "linear"
        }}
      />

      {/* Logo Container */}
      <motion.div
        className="flex flex-col items-center relative z-10"
        initial={{ scale: 1, y: 0 }}
        animate={{ 
          scale: 0.3,
          x: "-45vw",
          y: "-45vh"
        }}
        transition={{ 
          duration: 0.8, 
          delay: 1.5,
          ease: [0.43, 0.13, 0.23, 0.96]
        }}
      >
        {/* Logo Icon */}
        <motion.div
          className="relative"
          initial={{ scale: 0, rotate: -180 }}
          animate={{ scale: 1, rotate: 0 }}
          transition={{ 
            duration: 0.8,
            ease: [0.34, 1.56, 0.64, 1]
          }}
        >
          <motion.div
            className="w-40 h-40 bg-white rounded-full flex items-center justify-center shadow-2xl p-8"
            animate={{ 
              boxShadow: [
                "0 0 0 0 rgba(255, 255, 255, 0.7)",
                "0 0 0 20px rgba(255, 255, 255, 0)",
                "0 0 0 0 rgba(255, 255, 255, 0)"
              ]
            }}
            transition={{ 
              duration: 1.5,
              repeat: 1,
              delay: 0.5
            }}
          >
            <Logo size="lg" />
          </motion.div>
        </motion.div>

        {/* School Name */}
        <motion.div
          className="mt-8 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <motion.h1 
            className="text-white text-5xl mb-2"
            animate={{ 
              opacity: [1, 1, 0],
            }}
            transition={{ 
              duration: 0.5,
              times: [0, 0.8, 1],
              delay: 1.3
            }}
          >
            IPIKK
          </motion.h1>
          <motion.p 
            className="text-white/90 text-xl"
            animate={{ 
              opacity: [1, 1, 0],
            }}
            transition={{ 
              duration: 0.5,
              times: [0, 0.8, 1],
              delay: 1.3
            }}
          >
            Instituto Politécnico Industrial de Kuanza-Norte
          </motion.p>
        </motion.div>
      </motion.div>

      {/* Decorative Elements */}
      <motion.div
        className="absolute inset-0 overflow-hidden pointer-events-none"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 1 }}
      >
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-white rounded-full"
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
            animate={{
              scale: [0, 1, 0],
              opacity: [0, 1, 0],
            }}
            transition={{
              duration: 2,
              repeat: Infinity,
              delay: Math.random() * 2,
            }}
          />
        ))}
      </motion.div>
    </motion.div>
  );
}