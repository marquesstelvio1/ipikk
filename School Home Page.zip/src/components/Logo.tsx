// Componente de Logo do IPIKK
// Substitua a ImageWithFallback src com a URL da logo real do IPIKK

import { ImageWithFallback } from "./figma/ImageWithFallback";

interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Logo({ className = "", size = "md" }: LogoProps) {
  const sizeClasses = {
    sm: "h-8",
    md: "h-10",
    lg: "h-16"
  };

  // TODO: Substituir com a logo real do IPIKK de https://ipikk.ao/
  // Por enquanto, usando um placeholder
  return (
    <div className={`flex items-center gap-2 ${className}`}>
      <ImageWithFallback
        src="https://ipikk.ao/site/img/hero/logo.png"
        alt="IPIKK Logo"
        className={sizeClasses[size]}
      />
    </div>
  );
}
