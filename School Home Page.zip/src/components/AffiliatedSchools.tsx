import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, GraduationCap } from "lucide-react";

const schools = [
  { name: "Colégio de Luanda", location: "Luanda" },
  { name: "Liceu 1234", location: "Luanda" },
  { name: "Escola Técnica de Angola", location: "Benguela" },
  { name: "Instituto Politécnico do Huambo", location: "Huambo" },
  { name: "Escola Industrial de Benguela", location: "Benguela" },
  { name: "Liceu Técnico de Cabinda", location: "Cabinda" },
  { name: "Escola Profissional do Bié", location: "Bié" },
  { name: "Instituto de Formação do Uíge", location: "Uíge" }
];

export function AffiliatedSchools() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerView = 4;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        (prevIndex + 1) % Math.ceil(schools.length / itemsPerView)
      );
    }, 4000);

    return () => clearInterval(timer);
  }, []);

  const paginate = (direction: number) => {
    setCurrentIndex((prevIndex) => {
      const maxIndex = Math.ceil(schools.length / itemsPerView) - 1;
      let nextIndex = prevIndex + direction;
      if (nextIndex < 0) nextIndex = maxIndex;
      if (nextIndex > maxIndex) nextIndex = 0;
      return nextIndex;
    });
  };

  const visibleSchools = schools.slice(
    currentIndex * itemsPerView,
    (currentIndex + 1) * itemsPerView
  );

  return (
    <div className="relative">
      <motion.h3 
        className="text-white mb-6 flex items-center gap-2"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <GraduationCap className="w-5 h-5" />
        Escolas Filiadas
      </motion.h3>

      <div className="relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.5 }}
          >
            {visibleSchools.map((school, index) => (
              <motion.div
                key={index}
                className="bg-gray-800 rounded-lg p-4 hover:bg-gray-750 transition-colors"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -5 }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center flex-shrink-0">
                    <GraduationCap className="w-5 h-5 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-white truncate">{school.name}</p>
                    <p className="text-gray-400 text-sm">{school.location}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Buttons */}
        <button
          onClick={() => paginate(-1)}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
          aria-label="Anterior"
        >
          <ChevronLeft className="w-4 h-4 text-white" />
        </button>
        <button
          onClick={() => paginate(1)}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-8 h-8 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors"
          aria-label="Próximo"
        >
          <ChevronRight className="w-4 h-4 text-white" />
        </button>
      </div>

      {/* Indicators */}
      <div className="flex justify-center gap-2 mt-4">
        {Array.from({ length: Math.ceil(schools.length / itemsPerView) }).map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              index === currentIndex ? "bg-blue-600 w-6" : "bg-gray-700 w-1.5"
            }`}
            aria-label={`Ir para página ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
