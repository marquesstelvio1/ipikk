import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "./ui/card";
import { BookOpen, FlaskConical, Palette, Trophy } from "lucide-react";
import { motion } from "framer-motion";

export function Programs() {
  const programs = [
    {
      icon: BookOpen,
      title: "Formação Técnica",
      description: "Cursos técnicos especializados para formar profissionais qualificados nas diversas áreas industriais.",
      color: "text-blue-600",
      bgColor: "bg-blue-50"
    },
    {
      icon: FlaskConical,
      title: "Engenharia e Tecnologia",
      description: "Programas de formação em engenharia e tecnologia com infraestrutura moderna e corpo docente qualificado.",
      color: "text-green-600",
      bgColor: "bg-green-50"
    },
    {
      icon: Palette,
      title: "Desenvolvimento Industrial",
      description: "Preparação de técnicos para o setor industrial angolano com foco prático e inovador.",
      color: "text-purple-600",
      bgColor: "bg-purple-50"
    },
    {
      icon: Trophy,
      title: "Formação Profissional",
      description: "Capacitação profissional alinhada com as necessidades do mercado de trabalho angolano.",
      color: "text-orange-600",
      bgColor: "bg-orange-50"
    }
  ];

  return (
    <section id="programs" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div 
          className="text-center mb-12"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
        >
          <h2 className="mb-4">Cursos e Programas</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Oferecemos formação técnica e profissional de qualidade, preparando 
            os estudantes para os desafios do mercado de trabalho angolano.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {programs.map((program, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              whileHover={{ y: -8, transition: { duration: 0.2 } }}
            >
              <Card className="hover:shadow-lg transition-shadow h-full">
                <CardHeader>
                  <motion.div 
                    className={`w-12 h-12 rounded-lg ${program.bgColor} flex items-center justify-center mb-4`}
                    whileHover={{ scale: 1.1, rotate: 5 }}
                    transition={{ duration: 0.3 }}
                  >
                    <program.icon className={`w-6 h-6 ${program.color}`} />
                  </motion.div>
                  <CardTitle>{program.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <CardDescription>{program.description}</CardDescription>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}