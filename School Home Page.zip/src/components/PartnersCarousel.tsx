import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { ChevronLeft, ChevronRight, Handshake } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

const partners = [
  { 
    name: "Cisco", 
    description: "Networking & Cybersecurity",
    logo: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?w=200&h=100&fit=crop"
  },
  { 
    name: "ENDE", 
    description: "Empresa Nacional de Distribuição de Electricidade",
    logo: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=200&h=100&fit=crop"
  },
  { 
    name: "ITEL", 
    description: "Instituto de Telecomunicações",
    logo: "https://images.unsplash.com/photo-1560732488-6b0df240254a?w=200&h=100&fit=crop"
  },
  { 
    name: "Ministério das Telecomunicações", 
    description: "Governo de Angola",
    logo: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=200&h=100&fit=crop"
  },
  { 
    name: "Sonangol", 
    description: "Energia & Petróleo",
    logo: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?w=200&h=100&fit=crop"
  },
  { 
    name: "Microsoft", 
    description: "Tecnologia & Software",
    logo: "https://images.unsplash.com/photo-1633356122544-f134324a6cee?w=200&h=100&fit=crop"
  }
];

export function PartnersCarousel() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const itemsPerView = 3;

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentIndex((prevIndex) => 
        (prevIndex + 1) % Math.ceil(partners.length / itemsPerView)
      );
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const paginate = (direction: number) => {
    setCurrentIndex((prevIndex) => {
      const maxIndex = Math.ceil(partners.length / itemsPerView) - 1;
      let nextIndex = prevIndex + direction;
      if (nextIndex < 0) nextIndex = maxIndex;
      if (nextIndex > maxIndex) nextIndex = 0;
      return nextIndex;
    });
  };

  const visiblePartners = partners.slice(
    currentIndex * itemsPerView,
    (currentIndex + 1) * itemsPerView
  );

  return (
    <div className="relative">
      <motion.h3 
        className="text-white mb-6 flex items-center gap-2"
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
      >
        <Handshake className="w-5 h-5" />
        Parceiros
      </motion.h3>

      <div className="relative overflow-hidden">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.5 }}
          >
            {visiblePartners.map((partner, index) => (
              <motion.div
                key={index}
                className="bg-gray-800 rounded-lg p-6 hover:bg-gray-750 transition-colors group"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ scale: 1.05, y: -8 }}
              >
                <div className="flex flex-col items-center text-center gap-4">
                  {/* Logo Container */}
                  <div className="w-full h-24 bg-white rounded-lg flex items-center justify-center overflow-hidden group-hover:shadow-lg transition-shadow">
                    <ImageWithFallback
                      src={partner.logo}
                      alt={partner.name}
                      className="w-full h-full object-contain p-4"
                    />
                  </div>
                  {/* Info */}
                  <div>
                    <p className="text-white mb-1">{partner.name}</p>
                    <p className="text-gray-400 text-sm">{partner.description}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </AnimatePresence>

        {/* Navigation Buttons */}
        <button
          onClick={() => paginate(-1)}
          className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-4 w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors shadow-lg"
          aria-label="Anterior"
        >
          <ChevronLeft className="w-5 h-5 text-white" />
        </button>
        <button
          onClick={() => paginate(1)}
          className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-4 w-10 h-10 rounded-full bg-gray-800 hover:bg-gray-700 flex items-center justify-center transition-colors shadow-lg"
          aria-label="Próximo"
        >
          <ChevronRight className="w-5 h-5 text-white" />
        </button>
      </div>

      {/* Indicators */}
      <div className="flex justify-center gap-2 mt-6">
        {Array.from({ length: Math.ceil(partners.length / itemsPerView) }).map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentIndex(index)}
            className={`h-1.5 rounded-full transition-all duration-300 ${
              index === currentIndex ? "bg-blue-600 w-6" : "bg-gray-700 w-1.5"
            }`}
            aria-label={`Ir para página ${index + 1}`}
          />
        ))}
      </div>
    </div>
  );
}
