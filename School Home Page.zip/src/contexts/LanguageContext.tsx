import { createContext, useContext, useState, ReactNode } from "react";

type Language = "pt" | "en" | "fr" | "es";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  pt: {
    // Navigation
    "nav.home": "Início",
    "nav.about": "Sobre",
    "nav.courses": "Cursos",
    "nav.admissions": "Admissões",
    "nav.news": "Notícias",
    "nav.contact": "Contato",
    "nav.signup": "Inscreva-se",
    
    // Course Areas
    "courses.informatics": "Informática",
    "courses.accounting": "Contabilidade",
    "courses.electricity": "Eletricidade",
    "courses.mechanics": "Mecânica",
    "courses.construction": "Construção Civil",
    "courses.management": "Gestão e Administração",
    
    // Specific Courses
    "course.tech-informatics": "Técnico de Informática",
    "course.systems-management": "Gestão de Sistemas Informáticos",
    "course.accounting": "Contabilidade",
    "course.auditing": "Auditoria",
    "course.electrical-installations": "Instalações Elétricas",
    "course.industrial-electronics": "Eletrónica Industrial",
    "course.automotive-mechanics": "Mecânica Automóvel",
    "course.industrial-maintenance": "Manutenção Industrial",
    "course.civil-construction": "Construção Civil",
    "course.topography": "Topografia",
    "course.business-management": "Gestão de Empresas",
    "course.secretarial": "Secretariado",
    
    // Hero
    "hero.title": "Excelência em Formação Técnica e Profissional",
    "hero.subtitle": "Bem-vindo ao IPIKK - Instituto Politécnico Industrial de Kuanza-Norte, onde formamos profissionais qualificados para o desenvolvimento de Angola.",
    "hero.explore": "Explorar Programas",
    "hero.visit": "Agendar Visita",
    
    // Footer
    "footer.affiliated": "Escolas Filiadas",
    "footer.partners": "Parceiros",
    "footer.description": "Instituto Politécnico Industrial de Kuanza-Norte, formando profissionais qualificados para o desenvolvimento de Angola.",
    "footer.quicklinks": "Links Rápidos",
    "footer.aboutus": "Sobre Nós",
    "footer.programs": "Programas",
    "footer.newsevents": "Notícias & Eventos",
    "footer.contactus": "Contate-nos",
    "footer.followus": "Siga-nos",
    "footer.copyright": "© 2025 IPIKK - Instituto Politécnico Industrial de Kuanza-Norte. Todos os direitos reservados.",
    
    // Theme
    "theme.light": "Modo Claro",
    "theme.dark": "Modo Escuro",
  },
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.about": "About",
    "nav.courses": "Courses",
    "nav.admissions": "Admissions",
    "nav.news": "News",
    "nav.contact": "Contact",
    "nav.signup": "Sign Up",
    
    // Course Areas
    "courses.informatics": "Informatics",
    "courses.accounting": "Accounting",
    "courses.electricity": "Electricity",
    "courses.mechanics": "Mechanics",
    "courses.construction": "Civil Construction",
    "courses.management": "Management & Administration",
    
    // Specific Courses
    "course.tech-informatics": "IT Technician",
    "course.systems-management": "IT Systems Management",
    "course.accounting": "Accounting",
    "course.auditing": "Auditing",
    "course.electrical-installations": "Electrical Installations",
    "course.industrial-electronics": "Industrial Electronics",
    "course.automotive-mechanics": "Automotive Mechanics",
    "course.industrial-maintenance": "Industrial Maintenance",
    "course.civil-construction": "Civil Construction",
    "course.topography": "Topography",
    "course.business-management": "Business Management",
    "course.secretarial": "Secretarial Studies",
    
    // Hero
    "hero.title": "Excellence in Technical and Professional Training",
    "hero.subtitle": "Welcome to IPIKK - Kuanza-Norte Industrial Polytechnic Institute, where we train qualified professionals for Angola's development.",
    "hero.explore": "Explore Programs",
    "hero.visit": "Schedule Visit",
    
    // Footer
    "footer.affiliated": "Affiliated Schools",
    "footer.partners": "Partners",
    "footer.description": "Kuanza-Norte Industrial Polytechnic Institute, training qualified professionals for Angola's development.",
    "footer.quicklinks": "Quick Links",
    "footer.aboutus": "About Us",
    "footer.programs": "Programs",
    "footer.newsevents": "News & Events",
    "footer.contactus": "Contact Us",
    "footer.followus": "Follow Us",
    "footer.copyright": "© 2025 IPIKK - Kuanza-Norte Industrial Polytechnic Institute. All rights reserved.",
    
    // Theme
    "theme.light": "Light Mode",
    "theme.dark": "Dark Mode",
  },
  fr: {
    // Navigation
    "nav.home": "Accueil",
    "nav.about": "À propos",
    "nav.courses": "Cours",
    "nav.admissions": "Admissions",
    "nav.news": "Actualités",
    "nav.contact": "Contact",
    "nav.signup": "S'inscrire",
    
    // Course Areas
    "courses.informatics": "Informatique",
    "courses.accounting": "Comptabilité",
    "courses.electricity": "Électricité",
    "courses.mechanics": "Mécanique",
    "courses.construction": "Construction Civile",
    "courses.management": "Gestion et Administration",
    
    // Specific Courses
    "course.tech-informatics": "Technicien Informatique",
    "course.systems-management": "Gestion des Systèmes Informatiques",
    "course.accounting": "Comptabilité",
    "course.auditing": "Audit",
    "course.electrical-installations": "Installations Électriques",
    "course.industrial-electronics": "Électronique Industrielle",
    "course.automotive-mechanics": "Mécanique Automobile",
    "course.industrial-maintenance": "Maintenance Industrielle",
    "course.civil-construction": "Construction Civile",
    "course.topography": "Topographie",
    "course.business-management": "Gestion d'Entreprise",
    "course.secretarial": "Secrétariat",
    
    // Hero
    "hero.title": "Excellence en Formation Technique et Professionnelle",
    "hero.subtitle": "Bienvenue à l'IPIKK - Institut Polytechnique Industriel de Kuanza-Norte, où nous formons des professionnels qualifiés pour le développement de l'Angola.",
    "hero.explore": "Explorer les Programmes",
    "hero.visit": "Planifier une Visite",
    
    // Footer
    "footer.affiliated": "Écoles Affiliées",
    "footer.partners": "Partenaires",
    "footer.description": "Institut Polytechnique Industriel de Kuanza-Norte, formant des professionnels qualifiés pour le développement de l'Angola.",
    "footer.quicklinks": "Liens Rapides",
    "footer.aboutus": "À Propos",
    "footer.programs": "Programmes",
    "footer.newsevents": "Actualités & Événements",
    "footer.contactus": "Contactez-nous",
    "footer.followus": "Suivez-nous",
    "footer.copyright": "© 2025 IPIKK - Institut Polytechnique Industriel de Kuanza-Norte. Tous droits réservés.",
    
    // Theme
    "theme.light": "Mode Clair",
    "theme.dark": "Mode Sombre",
  },
  es: {
    // Navigation
    "nav.home": "Inicio",
    "nav.about": "Acerca",
    "nav.courses": "Cursos",
    "nav.admissions": "Admisiones",
    "nav.news": "Noticias",
    "nav.contact": "Contacto",
    "nav.signup": "Inscribirse",
    
    // Course Areas
    "courses.informatics": "Informática",
    "courses.accounting": "Contabilidad",
    "courses.electricity": "Electricidad",
    "courses.mechanics": "Mecánica",
    "courses.construction": "Construcción Civil",
    "courses.management": "Gestión y Administración",
    
    // Specific Courses
    "course.tech-informatics": "Técnico en Informática",
    "course.systems-management": "Gestión de Sistemas Informáticos",
    "course.accounting": "Contabilidad",
    "course.auditing": "Auditoría",
    "course.electrical-installations": "Instalaciones Eléctricas",
    "course.industrial-electronics": "Electrónica Industrial",
    "course.automotive-mechanics": "Mecánica Automotriz",
    "course.industrial-maintenance": "Mantenimiento Industrial",
    "course.civil-construction": "Construcción Civil",
    "course.topography": "Topografía",
    "course.business-management": "Gestión Empresarial",
    "course.secretarial": "Secretariado",
    
    // Hero
    "hero.title": "Excelencia en Formación Técnica y Profesional",
    "hero.subtitle": "Bienvenido al IPIKK - Instituto Politécnico Industrial de Kuanza-Norte, donde formamos profesionales calificados para el desarrollo de Angola.",
    "hero.explore": "Explorar Programas",
    "hero.visit": "Programar Visita",
    
    // Footer
    "footer.affiliated": "Escuelas Afiliadas",
    "footer.partners": "Socios",
    "footer.description": "Instituto Politécnico Industrial de Kuanza-Norte, formando profesionales calificados para el desarrollo de Angola.",
    "footer.quicklinks": "Enlaces Rápidos",
    "footer.aboutus": "Sobre Nosotros",
    "footer.programs": "Programas",
    "footer.newsevents": "Noticias y Eventos",
    "footer.contactus": "Contáctenos",
    "footer.followus": "Síguenos",
    "footer.copyright": "© 2025 IPIKK - Instituto Politécnico Industrial de Kuanza-Norte. Todos los derechos reservados.",
    
    // Theme
    "theme.light": "Modo Claro",
    "theme.dark": "Modo Oscuro",
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>("pt");

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.pt] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
}
