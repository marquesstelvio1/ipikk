import { Navigation } from "./components/Navigation";
import { Hero } from "./components/Hero";
import { Programs } from "./components/Programs";
import { News } from "./components/News";
import { Footer } from "./components/Footer";
import { SplashScreen } from "./components/SplashScreen";
import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { LanguageProvider } from "./contexts/LanguageContext";
import { ThemeProvider } from "./contexts/ThemeContext";

export default function App() {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <ThemeProvider>
      <LanguageProvider>
        <AnimatePresence>
          {showSplash && (
            <SplashScreen onComplete={() => setShowSplash(false)} />
          )}
        </AnimatePresence>

        <motion.div 
          className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-300"
          initial={{ opacity: 0 }}
          animate={{ opacity: showSplash ? 0 : 1 }}
          transition={{ duration: 0.5 }}
        >
          <Navigation />
          <Hero />
          <Programs />
          <News />
          <Footer />
        </motion.div>
      </LanguageProvider>
    </ThemeProvider>
  );
}